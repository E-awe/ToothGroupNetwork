"""CASE0001 component-level 3D review candidates; no clinical ground truth."""
import argparse
import csv
import hashlib
import json
import shutil
from pathlib import Path
import numpy as np
import trimesh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import plotly.graph_objects as go
from plotly.subplots import make_subplots

STATUS = '3d_review_candidate_pending_clinical_confirmation'
OVERRIDES = {('lower', 11): 44, ('lower', 12): 45}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def palette(fdi):
    if fdi == 0:
        return np.array([185, 185, 190, 255], dtype=np.uint8)
    hue = (((fdi // 10 - 1) * 8 + fdi % 10 - 1) * 0.61803398875) % 1
    rgb = matplotlib.colors.hsv_to_rgb([hue, .64, .94])
    return np.array([*np.rint(rgb * 255).astype(int), 255], dtype=np.uint8)


def save_csv(path, rows, fields):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def rgba(values):
    values = np.asarray(values, dtype=int)
    lut = np.zeros((int(values.max()) + 1, 4), dtype=np.uint8)
    for value in np.unique(values):
        lut[value] = palette(int(value))
    return lut[values]


def colored(mesh, values, path):
    colors = rgba(values)
    # Explicit float64 coordinates avoid any model OBJ -> float32 PLY rounding.
    vertex = np.empty(len(mesh.vertices), dtype=[('x','<f8'), ('y','<f8'), ('z','<f8'),
                     ('red','u1'), ('green','u1'), ('blue','u1'), ('alpha','u1')])
    for i, key in enumerate(['x','y','z']):
        vertex[key] = mesh.vertices[:,i]
    for i, key in enumerate(['red','green','blue','alpha']):
        vertex[key] = colors[:,i]
    faces = np.empty(len(mesh.faces), dtype=[('count','u1'), ('indices','<i4',(3,))])
    faces['count'] = 3; faces['indices'] = mesh.faces
    header = ('ply\nformat binary_little_endian 1.0\n'
              'comment CASE0001 derivative visualization; clinical confirmation pending\n'
              f'element vertex {len(vertex)}\nproperty double x\nproperty double y\nproperty double z\n'
              'property uchar red\nproperty uchar green\nproperty uchar blue\nproperty uchar alpha\n'
              f'element face {len(faces)}\nproperty list uchar int vertex_indices\nend_header\n')
    with path.open('wb') as f:
        f.write(header.encode('ascii')); f.write(vertex.tobytes()); f.write(faces.tobytes())
    loaded = trimesh.load_mesh(path, process=False)
    assert np.array_equal(loaded.vertices, mesh.vertices)
    assert np.array_equal(loaded.faces, mesh.faces)
    assert np.array_equal(loaded.visual.vertex_colors, colors)


def draw_panel(ax, mesh, ids, mapping, rows, title, elev):
    # Render all faces; source/model geometry is never resampled or rewritten.
    vertices = mesh.vertices
    face_values = np.array([mapping[int(c)] for c in ids[mesh.faces[:, 0]]])
    triangles = vertices[mesh.faces]
    colors = rgba(face_values) / 255.
    collection = Poly3DCollection(triangles, facecolors=colors, linewidths=0,
                                 edgecolors='none', rasterized=True)
    ax.add_collection3d(collection)
    for row in rows:
        c = int(row['component'])
        points = vertices[ids == c]
        center = points.mean(0)
        center[2] = points[:, 2].max() + 1.5
        fdi = mapping[c]
        text = f'C{c}: {fdi}' if row['role'] == 'tooth' else f'C{c}: BG(0)'
        changed = (row['jaw'], c) in OVERRIDES and fdi == OVERRIDES[(row['jaw'], c)]
        ax.text(*center, text, fontsize=7.5, ha='center', zorder=100,
                color='darkred' if changed else 'black',
                bbox=dict(facecolor='white', alpha=.85, edgecolor='darkred' if changed else 'none', pad=1))
    lo, hi = vertices.min(0), vertices.max(0)
    ax.set_xlim(lo[0] - 3, hi[0] + 3)
    ax.set_ylim(lo[1] - 3, hi[1] + 3)
    ax.set_zlim(lo[2] - 2, hi[2] + 5)
    ax.set_box_aspect(hi - lo + [6, 6, 7])
    ax.view_init(elev=elev, azim=-90)
    ax.set_xlabel('X'); ax.set_ylabel('Y'); ax.set_zlabel('Z')
    ax.set_title(title, fontsize=11)


def figure(mesh, ids, before, after, rows, jaw, path, coordinates):
    fig = plt.figure(figsize=(17, 13), layout='constrained')
    for k, (elev, mapping, name) in enumerate([
        (83, before, 'Original component predictions'),
        (83, after, '3D review candidates'),
        (28, before, 'Original component predictions'),
        (28, after, '3D review candidates'),
    ]):
        ax = fig.add_subplot(2, 2, k + 1, projection='3d')
        draw_panel(ax, mesh, ids, mapping, rows, name, elev)
    note = 'Upper: C1-C13 retained; missing-position candidate FDI15 (no mesh created).'
    if jaw == 'lower':
        note = 'Lower: C10 retained43; C11 43->44; C12 44->45; other components retained.'
    fig.suptitle(f'CASE0001 / {jaw.upper()} / {coordinates}\n{note}\n'
                 '3D REVIEW CANDIDATES - NOT CLINICALLY CONFIRMED', fontsize=14)
    fig.savefig(path, dpi=150)
    plt.close(fig)


def interactive(mesh, ids, before, after, rows, jaw, path):
    fig = make_subplots(rows=1, cols=2, specs=[[{'type': 'scene'}, {'type': 'scene'}]],
                        subplot_titles=['Original component predictions', '3D review candidates'])
    for column, mapping in [(1, before), (2, after)]:
        v = mesh.vertices; f = mesh.faces
        face_values = np.array([mapping[int(c)] for c in ids[f[:,0]]])
        face_colors = ['rgb(%d,%d,%d)' % tuple(rgb[:3]) for rgb in rgba(face_values)]
        fig.add_trace(go.Mesh3d(x=v[:, 0], y=v[:, 1], z=v[:, 2],
                               i=f[:, 0], j=f[:, 1], k=f[:, 2], facecolor=face_colors,
                               name='Component candidate colors', showscale=False), row=1, col=column)
        centers = np.array([v[ids == int(r['component'])].mean(0) for r in rows])
        labels = [f"C{r['component']}: {mapping[int(r['component'])]}" for r in rows]
        fig.add_trace(go.Scatter3d(x=centers[:, 0], y=centers[:, 1], z=centers[:, 2]+2,
                                  mode='markers+text', text=labels, textposition='top center',
                                  marker=dict(size=2, color='black'), showlegend=False), row=1, col=column)
    scene = dict(aspectmode='data', camera=dict(eye=dict(x=0, y=-.3, z=2.5)),
                 xaxis_title='Existing model X', yaxis_title='Existing model Y', zaxis_title='Existing model Z')
    fig.update_layout(scene=scene, scene2=scene, height=800,
                      title=f'CASE0001 {jaw}: 3D review candidates - NOT clinically confirmed',
                      annotations=list(fig.layout.annotations)+[dict(x=.5, y=-.05, xref='paper', yref='paper',
                          text='Upper missing candidate: FDI15' if jaw=='upper' else 'C10=43 retained; C11 43→44; C12 44→45',
                          showarrow=False)])
    fig.write_html(path, include_plotlyjs=True, full_html=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    source, out = args.source.resolve(), args.out.resolve()
    if out.exists():
        raise FileExistsError('Use a new output directory; source and previous reviews are preserved')
    hashes = {str(p.relative_to(source)): sha(p) for p in source.rglob('*') if p.is_file()}
    with (source/'component_fdi_candidates.csv').open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 29
    by_jaw = {jaw: [r for r in rows if r['jaw'] == jaw] for jaw in ['upper', 'lower']}
    assert [int(r['component']) for r in by_jaw['upper']] == list(range(1, 15))
    assert [int(r['component']) for r in by_jaw['lower']] == list(range(1, 16))
    assert int(by_jaw['lower'][9]['candidate_fdi']) == 43
    assert int(by_jaw['lower'][10]['candidate_fdi']) == 43
    assert int(by_jaw['lower'][11]['candidate_fdi']) == 44
    out.mkdir()
    baseline = out/'original_reference'; baseline.mkdir()
    shutil.copy2(source/'component_fdi_candidates.csv', baseline/'component_fdi_candidates.csv')
    shutil.copytree(source/'predictions', baseline/'predictions')
    for name in ['input_manifest.json', 'source_geometry.json']:
        shutil.copy2(source/name, baseline/name)
    manifest = json.loads((source/'input_manifest.json').read_text())
    summary = {'case_id': 'CASE0001', 'clinical_confirmation': False, 'status': STATUS,
               'changes': [], 'jaws': {}, 'missing_position_candidates': [{'jaw': 'upper', 'fdi': 15}],
               'patient_left_right_policy': 'Retain user-adopted CSV candidate convention; do not use mirror columns',
               'ply_semantics': 'Component-level uniform candidate colors; not a replacement vertex segmentation JSON',
               'plot_coordinates': 'Existing model coordinates, matching adopted review orientation; source-coordinate PLYs also retained',
               'source_file_sha256_before': hashes}
    reviewed_rows = []
    for jaw, jaw_rows in by_jaw.items():
        ids = np.load(source/f'{jaw}_vertex_components.npy', allow_pickle=False)
        original = {int(r['component']): int(r['candidate_fdi']) for r in jaw_rows}
        reviewed = {c: OVERRIDES.get((jaw, c), fdi) for c, fdi in original.items()}
        model = trimesh.load_mesh(source/f'input/CASE0001/CASE0001_{jaw}.obj', process=False)
        mesh = trimesh.load_mesh(source/f'{jaw}_predicted_source_coords.ply', process=False)
        transform = np.array(manifest[jaw]['rotation_source_to_model'])
        assert sha(source/f'input/CASE0001/CASE0001_{jaw}.obj') == manifest[jaw]['obj_sha256']
        assert ids.shape == (len(mesh.vertices),)
        assert np.array_equal(mesh.faces, model.faces)
        assert np.allclose(trimesh.transform_points(mesh.vertices, transform), model.vertices, atol=1e-8, rtol=0)
        assert np.array_equal(ids[mesh.faces[:, 0]], ids[mesh.faces[:, 1]])
        assert np.array_equal(ids[mesh.faces[:, 0]], ids[mesh.faces[:, 2]])
        prediction = json.loads((source/f'predictions/CASE0001_{jaw}.json').read_text())
        labels = np.array(prediction['labels'], dtype=np.int32)
        assert labels.shape == ids.shape
        for r in jaw_rows:
            c = int(r['component']); old = original[c]; new = reviewed[c]
            hist = dict(zip(*np.unique(labels[ids == c], return_counts=True)))
            if r['role'] == 'tooth':
                foreground = {int(k): int(v) for k, v in hist.items() if k != 0}
                assert max(foreground, key=foreground.get) == old
            else:
                assert old == new == 0
            reason = 'Preserve existing component mapping in user-adopted left/right convention after 3D review.'
            if old != new:
                reason = 'User-requested 3D arch review candidate correction; clinical record confirmation pending.'
                summary['changes'].append({'jaw': jaw, 'component': f'C{c}', 'original_prediction_fdi': old,
                                           'reviewed_candidate_fdi': new, 'reason': reason})
            if jaw == 'lower' and c == 10:
                reason = 'User explicitly retained C10=43 after 3D review; clinical record confirmation pending.'
            if r['role'] == 'gingiva':
                reason = 'Retain background/gingiva candidate0; not a tooth.'
            reviewed_rows.append(dict(case_id='CASE0001', jaw=jaw, component_id=f'C{c}', role=r['role'],
                record_type='component', original_prediction_fdi=old, original_arch_proposal_fdi=r['arch_review_proposal_fdi'],
                reviewed_candidate_fdi=new, candidate_changed=old != new, tooth_present=r['role']=='tooth',
                clinical_confirmed=False, review_status=STATUS, reason=reason,
                original_candidate_fraction=r['candidate_fraction'], original_foreground_label_purity=r['foreground_label_purity'],
                original_foreground_fraction=r['foreground_fraction'], original_flags=r['flags'],
                vertex_count=int((ids==c).sum())))
        old_values = np.array([original[int(c)] for c in ids])
        new_values = np.array([reviewed[int(c)] for c in ids])
        colored(mesh, old_values, out/f'{jaw}_original_component_candidates.ply')
        colored(mesh, new_values, out/f'{jaw}_reviewed_colored.ply')
        colored(model, new_values, out/f'{jaw}_reviewed_model_coords.ply')
        colored(mesh, labels, out/f'{jaw}_original_vertex_prediction.ply')
        np.save(out/f'{jaw}_vertex_components.npy', ids)
        np.savez(out/f'{jaw}_reviewed_component_candidates.npz', component_id=ids, original_component_fdi=old_values,
                 reviewed_component_fdi=new_values, raw_tgnet_vertex_fdi=labels)
        figure(model, ids, original, reviewed, jaw_rows, jaw, out/f'{jaw}_numbered_comparison.png', 'existing model coordinates')
        interactive(model, ids, original, reviewed, jaw_rows, jaw, out/f'{jaw}_reviewed_comparison.html')
        summary['jaws'][jaw] = {'vertices': len(mesh.vertices), 'faces': len(mesh.faces),
            'tooth_components': sum(r['role']=='tooth' for r in jaw_rows),
            'source_to_model_matrix': transform.tolist(), 'model_to_source_matrix': np.linalg.inv(transform).tolist(),
            'geometry_preserved': True, 'vertex_order_preserved': True,
            'raw_prediction_json_preserved': True, 'reviewed_mapping': {f'C{c}': f for c, f in reviewed.items()},
            'changed_candidate_vertices': int((old_values!=new_values).sum())}
        print(jaw, 'completed', flush=True)
    missing = dict.fromkeys(reviewed_rows[0], '')
    missing.update(case_id='CASE0001', jaw='upper', component_id='', role='missing_position', record_type='missing_tooth',
                   reviewed_candidate_fdi=15, candidate_changed=False, tooth_present=False, clinical_confirmed=False,
                   review_status=STATUS, reason='User-designated missing-position candidate FDI15 after 3D review; no mesh fabricated.')
    reviewed_rows.append(missing)
    save_csv(out/'reviewed_component_fdi.csv', reviewed_rows, list(reviewed_rows[0]))
    save_csv(out/'original_vs_reviewed_comparison.csv', reviewed_rows, list(reviewed_rows[0]))
    fields = ['jaw','component','original_prediction_fdi','reviewed_candidate_fdi','reason']
    save_csv(out/'changed_components.csv', summary['changes'], fields)
    after = {str(p.relative_to(source)): sha(p) for p in source.rglob('*') if p.is_file()}
    assert hashes == after
    assert len(summary['changes']) == 2
    summary['all_source_files_unchanged'] = True
    summary['source_file_sha256_after'] = after
    summary['output_file_sha256'] = {str(p.relative_to(out)): sha(p) for p in out.rglob('*') if p.is_file()}
    (out/'review_provenance.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    shutil.copy2(__file__, out/'build_review.py')
    print('CASE0001 review completed: 29 components + 1 missing-position record, 2 candidate changes; all source hashes unchanged.')


if __name__ == '__main__':
    main()
