已按官方 lcshhh/TADPM 提交 92967a68191846ab38dcdb2ae7914e19ecd0d396 准备当前病例的上颌数据，并实际运行官方 DentalDataset 的读取/特征构建函数与 batch=1 DataLoader 验证。没有运行 TADPM 排列预测，也没有编译 CUDA 扩展。

已生成 case_0：13颗牙单牙OBJ、13个before PLY、13个after加载占位PLY、13个MAPS16384面OBJ、32x3x3单位旋转占位、32项mask、原始坐标STL/OBJ副本、牙龈独立副本、归一化及逆矩阵、采样索引、软件版本与Dataset shape报告。after占位不是术后真值或排列预测，禁止用于训练或ADD评测。

源码核对：
1. get_pointcloud.py实际入口get_pointcloud_with_center：在before单牙mesh.vertices上做512点FPS，随机初始顶点；再追加mesh.centroid，PLY共513行。after使用before的同一组顶点索引，需要before/after顶点有真实一一对应关系；最后追加after_mesh.centroid。不是独立采样两个点云，也不是面上Poisson采样。
2. 点云不再/40，直接继承单牙OBJ坐标；centroid是Trimesh面积加权surface centroid，不是FPS点的均值。
3. get_mesh.py合并上下颌后统一以合并mesh.centroid居中，再/40，然后分牙。不能逐牙单独居中。当前没有下颌，采用原始完整上颌（含基底）surface centroid整体居中/40，明确标记upper-only adaptation，与有下颌时整体中心不同。不会自动沿用TGNet编号时的Rx旋转。
4. register.py初始化(32,3,3)单位矩阵，现存牙用Kabsch/必要时ICP求R，保存R.T。无平移或齐次4x4；after_centroid在PLY最后一行。行向量公式：P_after=(P_before-c_before)@stored_matrix+c_after。已用已知刚体变换实测官方Kabsch及此公式。
5. gt_params = [after_centroid, rotation6d]，形状(32,9)。matrix_to_rotation_6d取3x3矩阵前两行展平；单位矩阵6D=[1,0,0,0,1,0]。
6. 缺牙不生成对应OBJ或PLY，Dataset只有OBJ+before PLY+after PLY三者存在才设置mask=1。mask.npy只为审计保存，官方Dataset不读取此文件。缺牙的特征、点云、centroid、Fs都保持0；.npy该槽位仍为I3，所以gt_params不是全9维0，而是[0,0,0,1,0,0,0,1,0]。上颌缺槽0/3/15，下颌16–31全部缺失。mask在官方runner中用于损失/评测，模型forward未接收mask。
7. dataroot必须是remesh_before，不是single_before。官方QEM256+MAPS depth3得到16384面，按256patchx64face构建特征。任意STL面数或简单补齐面数不能保证这个层级顺序。当前原牙全watertight且法向一致，跳过不必要Manifold修复，保留原牙副本，仅对派生数据QEM/MAPS。使用pyfqmr0.3.0，官方requirements为0.2.0；相同API/参数，实际版本另行记录。

完整可执行脚本prepare_case.py和验证器validate_official_dataset.py。prepare_case.py直接提取并执行固定提交的FPS函数，直接调用固定提交MAPS源码；不会导入get_pointcloud.py的CLI顶层。上游requirements.txt有冲突重复项/无效项，不直接完整安装。

复现（推荐Python3.10–3.12；本轮实际为3.12.14 CPU）：
python -m pip install -r requirements-preprocess.txt
git clone https://github.com/lcshhh/TADPM.git TADPM
git -C TADPM checkout --detach 92967a68191846ab38dcdb2ae7914e19ecd0d396
python prepare_case.py --repo ./TADPM --whole-upper ./initial_upper.obj --components ./components --mapping ./component_fdi_slot.json --out ./case_0 --allow-after-placeholder

原始STL在components/component_0.stl到component_13.stl；mapping使用components字典、每项fdi和slot。输出目录必须不存在，避免旧结果混入。case_id默认为整数0，文件名为0_<slot>.obj/.ply，case_ids.txt内容0。

验证（需要CPU或GPU版torch，但不使用GPU）：
python validate_official_dataset.py --repo ./TADPM --case ./case_0

验证器运行官方DentalDataset类和load_mesh_shape函数原始body，隔离仅注册器装饰器；用等价纯Torch matrix_to_rotation_6d替代未安装PyTorch3D的该单一数学函数。不是完整模型或完整PyTorch3D安装验证。原仓库源码不修改。

Dataset单样本：index标量；feats(32,10,256,64)；center(32,256,64,3)；cordinates(32,256,64,9)；faces(32,256,64,3)；Fs(32,)；before/after_points(32,512,3)；centroid/after_centroid(32,3)；gt_params(32,9)；masks(32,)。DataLoader在前面加batch维B。原Dataset大多数输出float64，mask=int32，官方runner会把模型输入转float32。10个通道的实际构建顺序为area1、normal3、face_angles3、curvs3。

已有结果目录可迁移：配置路径为生成时的绝对路径，迁移后运行configure_case.py --case /new/path/case_0更新dataset_config.json；验证器也会按--case自动解析本地目录。

真实after尚未提供，所以pcd_after512_PLACEHOLDER复制before，param_PLACEHOLDER/0.npy为I3。下次若做真正模型推理，使用eval且不报告GT/ADD；如提供真正after，需要使用对应mesh及重新配准，不能继续使用这些占位目标。

归一化回原坐标：p_original=40*p_normalized+whole_upper_surface_centroid。矩阵和逆矩阵在reports/preparation.json。原始网格、标签、组件身份保持不变。输入方向与仅上颌病例的推理效果还需真实TADPM模型验证，本轮完成输入准备及读取验证。
