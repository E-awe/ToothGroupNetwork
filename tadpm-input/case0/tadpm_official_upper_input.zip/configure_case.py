import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--case',required=True);a=p.parse_args();r=Path(a.case).resolve();cfg=json.loads((r/'dataset_config.json').read_text())
for key,sub in {'dataroot':'remesh_before','paramroot':'param_PLACEHOLDER','before_path':'pcd_before512','after_path':'pcd_after512_PLACEHOLDER','file':'case_ids.txt'}.items():
    cfg[key]=str(r/sub)
(r/'dataset_config.json').write_text(json.dumps(cfg,indent=2)+'\n');print('Dataset config relocated to',r)
