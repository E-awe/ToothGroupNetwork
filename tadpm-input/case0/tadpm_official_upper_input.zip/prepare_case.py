"""Prepare this before-only upper case for official TADPM Dataset; CPU preprocessing only."""
import argparse, ast, hashlib, json, random, shutil, sys
from pathlib import Path
import numpy as np
import trimesh
import open3d as o3d
import pyfqmr

UPPER=[18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28]
COMMIT='92967a68191846ab38dcdb2ae7914e19ecd0d396'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def official_fps(repo):
    source=repo/'data_preprocess/get_pointcloud.py'
    node=next(x for x in ast.parse(source.read_text()).body
              if isinstance(x,ast.FunctionDef) and x.name=='farthest_point_sample')
    scope={'np':np}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),scope)
    return scope['farthest_point_sample']

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',required=True);p.add_argument('--whole-upper',required=True)
    p.add_argument('--components',required=True);p.add_argument('--mapping',required=True)
    p.add_argument('--out',required=True);p.add_argument('--case-id',type=int,default=0)
    p.add_argument('--npoint',type=int,default=512);p.add_argument('--seed',type=int,default=0)
    p.add_argument('--allow-after-placeholder',action='store_true',help='Explicitly permit after=before and identity rotations only for Dataset loading/inference, never treatment ground truth')
    a=p.parse_args()
    if not a.allow_after_placeholder:
        p.error('Only before data available: pass --allow-after-placeholder for inference loader compatibility; real after ground truth cannot be inferred')
    if a.case_id<0 or a.npoint!=512: p.error('Current verified case uses nonnegative integer ID and official 512 points')
    repo=Path(a.repo).resolve();src=Path(a.whole_upper).resolve();components=Path(a.components).resolve();out=Path(a.out).resolve()
    if out.exists():raise ValueError('Use a new output directory; existing data will not be overwritten')
    mapping=json.loads(Path(a.mapping).read_text());assert mapping['jaw']=='upper'
    import subprocess
    revision=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
    if revision!=COMMIT:raise ValueError(f'Verified upstream commit is {COMMIT}; got {revision}')
    mesh=trimesh.load_mesh(src,process=False)
    center=np.asarray(mesh.centroid)
    matrix=np.eye(4);matrix[:3,:3]/=40.0;matrix[:3,3]=-center/40.0
    folders=['original_coordinates','background','single_before','simplify_before','remesh_before','pcd_before512','pcd_after512_PLACEHOLDER','param_PLACEHOLDER','sampling_indices','reports']
    for name in folders:(out/name).mkdir(parents=True,exist_ok=False)
    shutil.copy2(src,out/'original_coordinates'/src.name)
    shutil.copy2(a.mapping,out/'component_fdi_slot.json')
    sys.path.insert(0,str(repo/'data_preprocess'))
    from maps import MAPS
    fps=official_fps(repo)
    mask=np.zeros(32,dtype=np.int32);rotations=np.tile(np.eye(3),(32,1,1));records=[]
    inputs_before={src:sha(src)}
    for name,values in mapping['components'].items():
        stl=components/(name+'.stl');inputs_before[stl]=sha(stl)
        shutil.copy2(stl,out/'original_coordinates'/stl.name)
        if values['fdi']==0:
            shutil.copy2(stl,out/'background'/stl.name);continue
        slot=values['slot'];fdi=values['fdi']
        if type(slot) is not int or not 0<=slot<16 or UPPER[slot]!=fdi or mask[slot]:
            raise ValueError(f'Invalid/duplicate upper slot for {name}')
        tooth=trimesh.load_mesh(stl,process=True)
        if not tooth.is_watertight or not tooth.is_winding_consistent:
            raise ValueError(f'{name}: needs a separate documented manifold repair')
        tooth.vertices=(tooth.vertices-center)/40.0
        obj=out/'single_before'/f'{a.case_id}_{slot}.obj';tooth.export(obj)
        # Reload exactly as official get_pointcloud.py does before FPS.
        tooth=trimesh.load_mesh(obj)
        if len(tooth.vertices)<a.npoint:raise ValueError(f'{name}: fewer than 512 unique vertices')
        np.random.seed(a.seed+slot);random.seed(a.seed+slot)
        points,selected=fps(tooth.vertices,a.npoint)
        points_with_center=np.concatenate([points,np.asarray(tooth.centroid)[None,:]])
        cloud=o3d.geometry.PointCloud();cloud.points=o3d.utility.Vector3dVector(points_with_center)
        ply=out/'pcd_before512'/f'{a.case_id}_{slot}.ply'
        if not o3d.io.write_point_cloud(str(ply),cloud):raise ValueError('PLY write failed')
        shutil.copy2(ply,out/'pcd_after512_PLACEHOLDER'/ply.name)
        np.save(out/'sampling_indices'/f'{a.case_id}_{slot}.npy',selected.astype(np.int64))
        # Official QEM base256 + upstream MAPS depth3 supplies 256 patches of 64 faces.
        simplifier=pyfqmr.Simplify();simplifier.setMesh(tooth.vertices,tooth.faces)
        simplifier.simplify_mesh(target_count=256,aggressiveness=7,preserve_border=True,verbose=False)
        v,f,_=simplifier.getMesh()
        if len(f)!=256:raise ValueError(f'{name}: QEM returned {len(f)} faces, expected256')
        base=trimesh.Trimesh(v,f,process=False)
        if not base.is_watertight:raise ValueError(f'{name}: QEM produced nonwatertight base')
        base.export(out/'simplify_before'/obj.name)
        maps=MAPS(v,f,base_size=256,timeout=20)
        remeshed=maps.mesh_upsampling(depth=3)
        if len(remeshed.faces)!=16384 or not np.isfinite(remeshed.vertices).all():
            raise ValueError(f'{name}: invalid MAPS mesh')
        remesh_path=out/'remesh_before'/obj.name;remeshed.export(remesh_path)
        mask[slot]=1
        records.append({'component':name,'source_stl_sha256':sha(stl),'slot':slot,'fdi':fdi,
                        'unique_mesh_vertices':len(tooth.vertices),'original_mesh_faces':len(tooth.faces),
                        'base_faces':len(f),'remesh_faces':len(remeshed.faces),
                        'ply_points':len(points_with_center),'ply_centroid_last_row':True,
                        'normalized_centroid':np.asarray(tooth.centroid).tolist(),
                        'after_is_placeholder':True,'param_is_placeholder':True,
                        'single_obj':str(obj.relative_to(out)),'remesh_obj':str(remesh_path.relative_to(out))})
        print(f'{name}: FDI{fdi}, slot{slot}, PLY513, MAPS16384 faces',flush=True)
    assert mask.sum()==13 and np.flatnonzero(mask[:16]==0).tolist()==[0,3,15]
    np.save(out/'param_PLACEHOLDER'/f'{a.case_id}.npy',rotations)
    np.save(out/'mask.npy',mask)
    (out/'case_ids.txt').write_text(str(a.case_id)+'\n')
    cfg={'NAME':'DentalDataset','train':False,'bs':1,'npoint':a.npoint,
         'dataroot':str(out/'remesh_before'),'paramroot':str(out/'param_PLACEHOLDER'),
         'before_path':str(out/'pcd_before512'),'after_path':str(out/'pcd_after512_PLACEHOLDER'),
         'file':str(out/'case_ids.txt')}
    (out/'dataset_config.json').write_text(json.dumps(cfg,indent=2)+'\n')
    report={'repo':'https://github.com/lcshhh/TADPM','commit':revision,'case_id':a.case_id,
            'source_obj_sha256':sha(src),'mapping_sha256':sha(a.mapping),'npoint':a.npoint,'seed':a.seed,
            'normalization':{'formula':'(p_original - whole_upper_surface_area_centroid) / 40.0',
                             'center':center.tolist(),'matrix':matrix.tolist(),'inverse_matrix':np.linalg.inv(matrix).tolist(),
                             'upper_only_adaptation':True,'official_reference':'get_mesh.py merges upper+lower before using merged mesh.centroid; no lower scan supplied',
                             'center_includes_upper_background':True,'rotation_applied':False,'per_tooth_centering_applied':False},
            'slot_count':32,'processed_slots':'upper0-15 only','lower_slots_all_absent':True,'mask':mask.tolist(),
            'absent_upper_slots':[0,3,15],'absent_upper_fdi':[18,15,28],
            'after_ground_truth_available':False,'after_policy':'Copied before PLY, solely to keep original Dataset mask/loader valid; not a treatment target or prediction',
            'param_policy':'Identity32x3x3 placeholders, including missing slots as register.py initializes; not registered treatment ground truth',
            'evaluation_allowed':False,'training_allowed':False,
            'manifold_stage':'Skipped because every original tooth is watertight and consistently wound; source geometry unchanged',
            'remeshing':'CPU QEM to256 followed by official MAPS depth3; derivative only, original-coordinate copies retained',
            'teeth':records,'script':str(Path(__file__).name)}
    (out/'reports/preparation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    assert all(sha(path)==value for path,value in inputs_before.items())
    print(f'Prepared {mask.sum()} teeth; lower16 slots zero; after/gt explicitly placeholders',flush=True)

if __name__=='__main__':main()
