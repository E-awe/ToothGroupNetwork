#!/usr/bin/env bash
set -euo pipefail
TASK_SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TADPM_REPO="${TADPM_REPO:-/workspace/TADPM}"
TASK_PYTHON="${TASK_PYTHON:-/workspace/toothgroup-environment/venv/bin/python}"
[[ $# == 4 ]] || { echo 'Usage: run_prepare.sh WHOLE_UPPER_OBJ COMPONENT_STL_DIR MAPPING_JSON NEW_OUTPUT_DIR' >&2; exit 2; }
"$TASK_PYTHON" "$TASK_SCRIPT_DIR/prepare_case.py" --repo "$TADPM_REPO" \
  --whole-upper "$1" --components "$2" --mapping "$3" --out "$4" --allow-after-placeholder
"$TASK_PYTHON" "$TASK_SCRIPT_DIR/validate_official_dataset.py" --repo "$TADPM_REPO" --case "$4"
