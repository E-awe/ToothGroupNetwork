"""Execute official Dataset bodies on CPU with isolated registry and equivalent 6D conversion."""
import argparse,ast,json,os
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
import trimesh
import open3d as o3d
import torch.utils.data as data

FIELDS=['index','feats','center','cordinates','faces','Fs','before_points','after_points','centroid','after_centroid','gt_params','masks']

def read_pointcloud(path):return np.asarray(o3d.io.read_point_cloud(str(path)).points)

def matrix_to_rotation_6d(matrix):
    # PyTorch3D standard convention: first two ROWS flattened, not columns.
    return matrix[..., :2, :].clone().reshape(*matrix.shape[:-2],6)

def load_original_class(repo):
    path=repo/'datasets/DentalDataset.py';tree=ast.parse(path.read_text())
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ('load_mesh_shape','DentalDataset')]
    for n in nodes:
        if isinstance(n,ast.ClassDef):n.decorator_list=[]  # Registry registration only; dataset bodies unchanged.
    env={'np':np,'os':os,'torch':torch,'trimesh':trimesh,'data':data,
         'read_pointcloud':read_pointcloud,'matrix_to_rotation_6d':matrix_to_rotation_6d}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),env)
    return env['DentalDataset']

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--case',required=True);a=p.parse_args()
    repo=Path(a.repo);case=Path(a.case).resolve();cfg=json.loads((case/'dataset_config.json').read_text())
    for key,sub in {'dataroot':'remesh_before','paramroot':'param_PLACEHOLDER','before_path':'pcd_before512','after_path':'pcd_after512_PLACEHOLDER','file':'case_ids.txt'}.items():cfg[key]=str(case/sub)
    dataset=load_original_class(repo)(SimpleNamespace(**cfg));assert len(dataset)==1
    item=dataset[0];expected=[(),(32,10,256,64),(32,256,64,3),(32,256,64,9),(32,256,64,3),(32,),(32,512,3),(32,512,3),(32,3),(32,3),(32,9),(32,)]
    values={}
    for key,value,shape in zip(FIELDS,item,expected):
        arr=value.detach().cpu().numpy() if isinstance(value,torch.Tensor) else np.asarray(value)
        assert arr.shape==shape,(key,arr.shape,shape)
        assert np.isfinite(arr).all(),key
        values[key]={'shape':list(arr.shape),'dtype':str(arr.dtype)}
    mask=np.asarray(item[-1]);assert np.array_equal(mask,np.load(case/'mask.npy'));assert mask.sum()==13 and np.all(mask[16:]==0)
    matrix=np.load(case/'param_PLACEHOLDER'/f'{item[0]}.npy');assert matrix.shape==(32,3,3);assert np.allclose(matrix,np.eye(3))
    for slot in np.flatnonzero(mask):
        pc=read_pointcloud(case/'pcd_before512'/f'{item[0]}_{slot}.ply');assert pc.shape==(513,3)
        assert np.allclose(item[6][slot],pc[:512]);assert np.allclose(item[8][slot],pc[512])
        assert np.array_equal(item[6][slot],item[7][slot]);assert item[5][slot]==16384
    for position in (1,2,3,4,5,6,7,8,9):assert np.all(np.asarray(item[position])[mask==0]==0)
    # Missing gt_params are zero centroid plus identity6D, rather than all-zero9D.
    identity=np.array([1,0,0,0,1,0]);assert np.allclose(item[10][:,3:].numpy(),identity)
    loader=data.DataLoader(dataset,batch_size=1,shuffle=False,num_workers=0,drop_last=False)
    batch=next(iter(loader));batch_shapes={k:list(v.shape) for k,v in zip(FIELDS,batch)}
    report={'actual_official_dataset_bodies_executed':True,'registry_registration_isolated':True,
            'pytorch3d_6d_implementation':'Equivalent pure Torch conversion of first two rows; full PyTorch3D package not installed',
            'full_tadpm_model_executed':False,'sample_shapes':values,'batch_shapes':batch_shapes,
            'mask':mask.tolist(),'present_teeth':int(mask.sum()),'missing_upper_slots':[0,3,15],
            'ply_length':513,'npoint':512,'per_tooth_remesh_faces':16384,
            'all_finite':True,'original_dataset_source_modified':False,
            'after_and_gt_placeholders':True,'evaluation_or_training_with_placeholders_allowed':False}
    (case/'reports/dataset_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    # Save readily inspected tensors; float32 is the runner's model input convention.
    tensors={k:torch.as_tensor(v).float() if k not in ('index','masks') else torch.as_tensor(v) for k,v in zip(FIELDS,item)}
    torch.save({'sample':tensors,'metadata':report},case/'reports/loader_smoke_only.pt')

if __name__=='__main__':main()
